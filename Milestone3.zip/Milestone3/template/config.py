# Global Setting for the Database
# PageSize, StartRID, etc..
def init():
    pass
